from flask import Flask, render_template, request, send_file
from utils.gem_scraper import GemScraper
from utils.pdf_extractor import PDFExtractor
from utils.excel_generator import ExcelGenerator
import os

app = Flask(__name__)

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/search', methods=['POST'])
def search():
    bid_number = request.form['bid_number']
    
    # Initialize components
    scraper = GemScraper()
    pdf_extractor = PDFExtractor()
    excel_generator = ExcelGenerator()
    
    try:
        # Search and download BID details
        bid_details = scraper.search_bid(bid_number)
        pdf_path = scraper.download_bid_document(bid_number)
        
        # Extract specifications from PDF
        specifications = pdf_extractor.extract_specifications(pdf_path)
        
        # Generate Excel file
        excel_path = excel_generator.generate_excel(specifications, bid_number)
        
        return render_template('result.html', 
                             bid_details=bid_details,
                             excel_path=excel_path)
    
    except Exception as e:
        return render_template('index.html', error=str(e))

if __name__ == '__main__':
    app.run(debug=True)