import pandas as pd

class ExcelGenerator:
    def generate_excel(self, specifications, bid_number):
        try:
            # Convert specifications to DataFrame
            df = pd.DataFrame(specifications)
            
            # Generate Excel file
            output_path = f"static/exports/{bid_number}_specs.xlsx"
            df.to_excel(output_path, index=False)
            return output_path
        except Exception as e:
            raise Exception(f"Error generating Excel: {str(e)}")