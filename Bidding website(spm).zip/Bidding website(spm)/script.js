const express = require("express");
const puppeteer = require("puppeteer");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const ExcelJS = require("exceljs");

const app = express();
app.use(express.json());
app.use(cors());
app.use(express.static("public"));

const GEM_BID_SEARCH_URL = "https://bidplus.gem.gov.in/bidlists"; // Update with correct URL

app.get("/bid-info", async (req, res) => {
    const { bidNumber } = req.query;
    if (!bidNumber) {
        return res.status(400).json({ status: "Error", message: "BID number is required" });
    }

    try {
        const browser = await puppeteer.launch({ headless: false });
        const page = await browser.newPage();
        await page.goto(GEM_BID_SEARCH_URL, { waitUntil: "networkidle2" });

        // Input BID number and search
        await page.waitForSelector("#bid_no"); // Update this selector if needed
        await page.type("#bid_no", bidNumber);
        await page.click("#search_button"); // Update with actual button selector
        await page.waitForTimeout(5000); // Give time for the page to load

        // Extract bid details
        const bidInfo = await page.evaluate(() => {
            let bidElement = document.querySelector(".bid-details"); // Update if incorrect
            return bidElement ? bidElement.innerText : "No bid details found.";
        });

        // Download BID document
        const docPath = path.join(__dirname, `public/BID_${bidNumber}.pdf`);
        const pdfBuffer = await page.pdf({ format: "A4" });
        fs.writeFileSync(docPath, pdfBuffer);

        // Extract product specifications
        const specifications = await page.evaluate(() => {
            let specs = [];
            document.querySelectorAll(".specifications-table tr").forEach(row => {
                const cols = row.querySelectorAll("td");
                if (cols.length === 2) {
                    specs.push({ name: cols[0].innerText.trim(), value: cols[1].innerText.trim() });
                }
            });
            return specs;
        });

        // Save specifications to Excel
        const workbook = new ExcelJS.Workbook();
        const sheet = workbook.addWorksheet("Specifications");
        sheet.addRow(["Specification", "Value"]);
        specifications.forEach(spec => {
            sheet.addRow([spec.name, spec.value]);
        });
        const filePath = path.join(__dirname, `public/Specifications_${bidNumber}.xlsx`);
        await workbook.xlsx.writeFile(filePath);

        await browser.close();

        res.json({
            status: "Success",
            bidDetails: bidInfo,
            documentPath: `BID_${bidNumber}.pdf`,
            excelPath: `Specifications_${bidNumber}.xlsx`
        });
    } catch (error) {
        res.status(500).json({ status: "Error", message: "Failed to retrieve bid information: " + error.message });
    }
});

app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});
